package com.example.michaeljosilcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private StringBuilder input;
    private DecimalFormat decimalFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        input = new StringBuilder();
        decimalFormat = new DecimalFormat("#.##########");
    }

    public void onNumberClick(View view) {
        Button button = (Button) view;
        input.append(button.getText().toString());
        updateResult();
    }

    public void onOperatorClick(View view) {
        Button button = (Button) view;
        input.append(" ").append(button.getText().toString()).append(" ");
        updateResult();
    }

    public void onClearClick(View view) {
        input.setLength(0);
        updateResult();
    }

    public void onBackspaceClick(View view) {
        if (input.length() > 0) {
            input.deleteCharAt(input.length() - 1);
            updateResult();
        }
    }

    public void onEqualClick(View view) {
        String expression = input.toString();
        String[] tokens = expression.split(" ");

        if (tokens.length != 3) {
            return;
        }

        double num1 = Double.parseDouble(tokens[0]);
        double num2 = Double.parseDouble(tokens[2]);
        double result;

        switch (tokens[1]) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "*":
                result = num1 * num2;
                break;
            case "/":
                result = num1 / num2;
                break;
            default:
                return;
        }

        input.setLength(0);
        input.append(decimalFormat.format(result));
        updateResult();
    }

    private void updateResult() {
        tvResult.setText(input.toString());
    }
}

